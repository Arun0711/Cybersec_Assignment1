"""
Setup script for CVE Exploitation Prediction System
Run this script to verify your environment is properly configured
"""

import sys
import subprocess
from pathlib import Path

def check_python_version():
    """Check if Python version is adequate."""
    print("Checking Python version...")
    version = sys.version_info
    if version.major >= 3 and version.minor >= 8:
        print(f"✓ Python {version.major}.{version.minor}.{version.micro} (OK)")
        return True
    else:
        print(f"✗ Python {version.major}.{version.minor}.{version.micro} (Need >= 3.8)")
        return False

def check_dependencies():
    """Check if required packages are installed."""
    print("\nChecking dependencies...")
    
    required_packages = [
        'pandas', 'numpy', 'scikit-learn', 'xgboost', 'lightgbm',
        'imbalanced-learn', 'requests', 'matplotlib', 'seaborn',
        'tqdm', 'jupyter', 'nltk'
    ]
    
    missing = []
    for package in required_packages:
        try:
            __import__(package.replace('-', '_'))
            print(f"✓ {package}")
        except ImportError:
            print(f"✗ {package} (NOT FOUND)")
            missing.append(package)
    
    return missing

def setup_directories():
    """Create necessary directories."""
    print("\nSetting up directories...")
    
    base_dir = Path(__file__).parent
    directories = [
        base_dir / 'data' / 'raw',
        base_dir / 'data' / 'processed',
        base_dir / 'data' / 'models',
    ]
    
    for directory in directories:
        directory.mkdir(parents=True, exist_ok=True)
        print(f"✓ {directory.relative_to(base_dir)}")

def download_nltk_data():
    """Download required NLTK data."""
    print("\nDownloading NLTK data...")
    
    try:
        import nltk
        nltk.download('punkt', quiet=True)
        nltk.download('stopwords', quiet=True)
        print("✓ NLTK data downloaded")
        return True
    except Exception as e:
        print(f"✗ Failed to download NLTK data: {e}")
        return False

def verify_modules():
    """Verify project modules can be imported."""
    print("\nVerifying project modules...")
    
    sys.path.insert(0, str(Path(__file__).parent))
    
    modules = [
        'config',
        'src.utils',
        'src.data_collection',
        'src.feature_engineering',
        'src.preprocessing',
        'src.models',
        'src.evaluation'
    ]
    
    success = True
    for module in modules:
        try:
            __import__(module)
            print(f"✓ {module}")
        except ImportError as e:
            print(f"✗ {module}: {e}")
            success = False
    
    return success

def main():
    """Main setup function."""
    print("="*60)
    print("CVE Exploitation Prediction System - Setup Verification")
    print("="*60)
    
    # Check Python version
    if not check_python_version():
        print("\n❌ Setup failed: Python version too old")
        return False
    
    # Check dependencies
    missing = check_dependencies()
    if missing:
        print(f"\n⚠️ Missing packages: {', '.join(missing)}")
        print("\nInstall missing packages with:")
        print(f"   pip install {' '.join(missing)}")
        
        response = input("\nInstall now? (y/n): ").lower()
        if response == 'y':
            print("\nInstalling packages...")
            subprocess.check_call([
                sys.executable, '-m', 'pip', 'install'
            ] + missing)
            print("✓ Packages installed")
        else:
            print("\n❌ Setup incomplete: Install packages manually")
            return False
    
    # Setup directories
    setup_directories()
    
    # Download NLTK data
    if not download_nltk_data():
        print("\n⚠️ NLTK data download failed - some features may not work")
    
    # Verify modules
    if not verify_modules():
        print("\n❌ Some project modules failed to import")
        return False
    
    print("\n" + "="*60)
    print("✅ SETUP COMPLETE!")
    print("="*60)
    print("\nNext steps:")
    print("1. Review QUICKSTART.md for usage instructions")
    print("2. Open notebooks/main_analysis.ipynb in Jupyter")
    print("3. Run the notebook cells to see the complete pipeline")
    print("\nOptional:")
    print("- Set NVD_API_KEY environment variable for faster data collection")
    print("- Run 'python src/data_collection.py' to collect real CVE data")
    print("\nHappy analyzing! 🔒🤖")
    
    return True

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
