"""
Machine Learning Models for CVE Exploitation Prediction

Implements multiple classifiers with class imbalance handling:
- Logistic Regression (baseline)
- Random Forest
- XGBoost
- LightGBM
"""

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_val_score, StratifiedKFold
from imblearn.over_sampling import SMOTE
from imblearn.pipeline import Pipeline as ImbPipeline
import xgboost as xgb
import lightgbm as lgb
import joblib

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent.parent))

from config import (
    RANDOM_STATE, RANDOM_FOREST_PARAMS, XGBOOST_PARAMS, LIGHTGBM_PARAMS,
    SMOTE_SAMPLING_STRATEGY, MODELS_DIR
)


class CVEClassifier:
    """Base class for CVE exploitation classifiers."""
    
    def __init__(self, model_name: str, use_smote: bool = True):
        """
        Initialize classifier.
        
        Args:
            model_name: Name of the model
            use_smote: Whether to use SMOTE for handling class imbalance
        """
        self.model_name = model_name
        self.use_smote = use_smote
        self.model = None
        self.pipeline = None
        
    def build_model(self):
        """Build the model. To be implemented by subclasses."""
        raise NotImplementedError
        
    def train(self, X_train: pd.DataFrame, y_train: pd.Series):
        """
        Train the model.
        
        Args:
            X_train: Training features
            y_train: Training labels
        """
        print(f"\n{'='*60}")
        print(f"Training {self.model_name}")
        print(f"{'='*60}")
        
        if self.use_smote:
            print(f"Using SMOTE with sampling strategy: {SMOTE_SAMPLING_STRATEGY}")
            
            # Create pipeline with SMOTE
            smote = SMOTE(
                sampling_strategy=SMOTE_SAMPLING_STRATEGY,
                random_state=RANDOM_STATE,
                k_neighbors=5
            )
            
            self.pipeline = ImbPipeline([
                ('smote', smote),
                ('classifier', self.model)
            ])
            
            self.pipeline.fit(X_train, y_train)
        else:
            self.model.fit(X_train, y_train)
        
        print(f"{self.model_name} training complete")
        
    def predict(self, X: pd.DataFrame) -> np.ndarray:
        """
        Make predictions.
        
        Args:
            X: Features
            
        Returns:
            Binary predictions
        """
        if self.use_smote:
            return self.pipeline.predict(X)
        else:
            return self.model.predict(X)
    
    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        """
        Predict class probabilities.
        
        Args:
            X: Features
            
        Returns:
            Probability predictions
        """
        if self.use_smote:
            return self.pipeline.predict_proba(X)
        else:
            return self.model.predict_proba(X)
    
    def save_model(self, filepath: Path = None):
        """
        Save trained model to disk.
        
        Args:
            filepath: Path to save model
        """
        if filepath is None:
            filepath = MODELS_DIR / f'{self.model_name.lower().replace(" ", "_")}.pkl'
        
        model_to_save = self.pipeline if self.use_smote else self.model
        joblib.dump(model_to_save, filepath)
        print(f"Model saved to {filepath}")
    
    def load_model(self, filepath: Path):
        """
        Load trained model from disk.
        
        Args:
            filepath: Path to load model from
        """
        if self.use_smote:
            self.pipeline = joblib.load(filepath)
        else:
            self.model = joblib.load(filepath)
        print(f"Model loaded from {filepath}")
    
    def cross_validate(self, X: pd.DataFrame, y: pd.Series, cv: int = 5) -> dict:
        """
        Perform cross-validation.
        
        Args:
            X: Features
            y: Labels
            cv: Number of cross-validation folds
            
        Returns:
            Dictionary of cross-validation scores
        """
        print(f"\nPerforming {cv}-fold cross-validation for {self.model_name}...")
        
        skf = StratifiedKFold(n_splits=cv, shuffle=True, random_state=RANDOM_STATE)
        
        model_to_cv = self.pipeline if self.use_smote else self.model
        
        # Calculate multiple metrics
        scoring = ['accuracy', 'precision', 'recall', 'f1', 'roc_auc']
        scores = {}
        
        for metric in scoring:
            cv_scores = cross_val_score(
                model_to_cv, X, y,
                cv=skf,
                scoring=metric,
                n_jobs=-1
            )
            scores[metric] = {
                'mean': cv_scores.mean(),
                'std': cv_scores.std(),
                'scores': cv_scores
            }
            print(f"{metric}: {cv_scores.mean():.4f} (+/- {cv_scores.std():.4f})")
        
        return scores


class LogisticRegressionClassifier(CVEClassifier):
    """Logistic Regression classifier for CVE exploitation prediction."""
    
    def __init__(self, use_smote: bool = True):
        """Initialize Logistic Regression classifier."""
        super().__init__("Logistic Regression", use_smote)
        self.build_model()
    
    def build_model(self):
        """Build Logistic Regression model."""
        self.model = LogisticRegression(
            max_iter=1000,
            class_weight='balanced' if not self.use_smote else None,
            random_state=RANDOM_STATE,
            n_jobs=-1
        )


class RandomForestClassifier_(CVEClassifier):
    """Random Forest classifier for CVE exploitation prediction."""
    
    def __init__(self, use_smote: bool = True, **kwargs):
        """Initialize Random Forest classifier."""
        super().__init__("Random Forest", use_smote)
        self.params = {**RANDOM_FOREST_PARAMS, **kwargs}
        if use_smote:
            self.params['class_weight'] = None
        self.build_model()
    
    def build_model(self):
        """Build Random Forest model."""
        self.model = RandomForestClassifier(**self.params)
    
    def get_feature_importance(self, feature_names: list) -> pd.DataFrame:
        """
        Get feature importance scores.
        
        Args:
            feature_names: List of feature names
            
        Returns:
            DataFrame with feature importances
        """
        if self.use_smote:
            importances = self.pipeline.named_steps['classifier'].feature_importances_
        else:
            importances = self.model.feature_importances_
        
        importance_df = pd.DataFrame({
            'feature': feature_names,
            'importance': importances
        }).sort_values('importance', ascending=False)
        
        return importance_df


class XGBoostClassifier(CVEClassifier):
    """XGBoost classifier for CVE exploitation prediction."""
    
    def __init__(self, use_smote: bool = True, **kwargs):
        """Initialize XGBoost classifier."""
        super().__init__("XGBoost", use_smote)
        self.params = {**XGBOOST_PARAMS, **kwargs}
        if use_smote:
            self.params['scale_pos_weight'] = 1  # SMOTE handles balancing
        self.build_model()
    
    def build_model(self):
        """Build XGBoost model."""
        self.model = xgb.XGBClassifier(**self.params)
    
    def get_feature_importance(self, feature_names: list) -> pd.DataFrame:
        """
        Get feature importance scores.
        
        Args:
            feature_names: List of feature names
            
        Returns:
            DataFrame with feature importances
        """
        if self.use_smote:
            importances = self.pipeline.named_steps['classifier'].feature_importances_
        else:
            importances = self.model.feature_importances_
        
        importance_df = pd.DataFrame({
            'feature': feature_names,
            'importance': importances
        }).sort_values('importance', ascending=False)
        
        return importance_df


class LightGBMClassifier(CVEClassifier):
    """LightGBM classifier for CVE exploitation prediction."""
    
    def __init__(self, use_smote: bool = True, **kwargs):
        """Initialize LightGBM classifier."""
        super().__init__("LightGBM", use_smote)
        self.params = {**LIGHTGBM_PARAMS, **kwargs}
        if use_smote:
            self.params['class_weight'] = None
        self.build_model()
    
    def build_model(self):
        """Build LightGBM model."""
        self.model = lgb.LGBMClassifier(**self.params, verbose=-1)
    
    def get_feature_importance(self, feature_names: list) -> pd.DataFrame:
        """
        Get feature importance scores.
        
        Args:
            feature_names: List of feature names
            
        Returns:
            DataFrame with feature importances
        """
        if self.use_smote:
            importances = self.pipeline.named_steps['classifier'].feature_importances_
        else:
            importances = self.model.feature_importances_
        
        importance_df = pd.DataFrame({
            'feature': feature_names,
            'importance': importances
        }).sort_values('importance', ascending=False)
        
        return importance_df


def train_all_models(X_train: pd.DataFrame, 
                     y_train: pd.Series,
                     use_smote: bool = True) -> dict:
    """
    Train all models.
    
    Args:
        X_train: Training features
        y_train: Training labels
        use_smote: Whether to use SMOTE
        
    Returns:
        Dictionary of trained models
    """
    models = {
        'logistic_regression': LogisticRegressionClassifier(use_smote=use_smote),
        'random_forest': RandomForestClassifier_(use_smote=use_smote),
        'xgboost': XGBoostClassifier(use_smote=use_smote),
        'lightgbm': LightGBMClassifier(use_smote=use_smote)
    }
    
    for name, model in models.items():
        model.train(X_train, y_train)
        model.save_model()
    
    return models


if __name__ == "__main__":
    from src.preprocessing import DataPreprocessor
    from src.utils import load_pickle
    from config import PROCESSED_DATA_DIR
    
    # Load feature data
    feature_path = PROCESSED_DATA_DIR / 'features.pkl'
    df = load_pickle(feature_path)
    
    # Prepare data
    preprocessor = DataPreprocessor(temporal_split=True)
    data = preprocessor.prepare_data(df, scale=True)
    
    # Train all models
    print("\n" + "="*60)
    print("Training all models...")
    print("="*60)
    
    models = train_all_models(
        data['X_train'],
        data['y_train'],
        use_smote=True
    )
    
    print("\nAll models trained successfully!")
