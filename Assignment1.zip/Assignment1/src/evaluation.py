"""
Evaluation Module for CVE Exploitation Prediction

Provides comprehensive evaluation metrics and visualizations including:
- Classification metrics (precision, recall, F1, ROC-AUC, PR-AUC)
- Confusion matrices
- Feature importance analysis
- Cost-sensitive evaluation
- Threshold optimization
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, average_precision_score, confusion_matrix,
    classification_report, roc_curve, precision_recall_curve,
    matthews_corrcoef
)

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent.parent))

from config import FP_COST, FN_COST, CLASSIFICATION_THRESHOLD


class ModelEvaluator:
    """Comprehensive model evaluation for CVE exploitation prediction."""
    
    def __init__(self, model_name: str = "Model"):
        """
        Initialize evaluator.
        
        Args:
            model_name: Name of the model being evaluated
        """
        self.model_name = model_name
        self.metrics = {}
        
    def calculate_metrics(self, y_true: np.ndarray, y_pred: np.ndarray, 
                         y_pred_proba: np.ndarray = None) -> dict:
        """
        Calculate comprehensive classification metrics.
        
        Args:
            y_true: True labels
            y_pred: Predicted labels
            y_pred_proba: Predicted probabilities (for positive class)
            
        Returns:
            Dictionary of metrics
        """
        metrics = {}
        
        # Basic metrics
        metrics['accuracy'] = accuracy_score(y_true, y_pred)
        metrics['precision'] = precision_score(y_true, y_pred, zero_division=0)
        metrics['recall'] = recall_score(y_true, y_pred, zero_division=0)
        metrics['f1'] = f1_score(y_true, y_pred, zero_division=0)
        metrics['mcc'] = matthews_corrcoef(y_true, y_pred)
        
        # Probability-based metrics
        if y_pred_proba is not None:
            metrics['roc_auc'] = roc_auc_score(y_true, y_pred_proba)
            metrics['pr_auc'] = average_precision_score(y_true, y_pred_proba)
        
        # Confusion matrix components
        tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
        metrics['true_positives'] = tp
        metrics['false_positives'] = fp
        metrics['true_negatives'] = tn
        metrics['false_negatives'] = fn
        
        # Derived metrics
        metrics['specificity'] = tn / (tn + fp) if (tn + fp) > 0 else 0
        metrics['fpr'] = fp / (fp + tn) if (fp + tn) > 0 else 0
        
        self.metrics = metrics
        return metrics
    
    def calculate_cost_sensitive_metric(self, y_true: np.ndarray, y_pred: np.ndarray,
                                       fp_cost: float = FP_COST, 
                                       fn_cost: float = FN_COST) -> float:
        """
        Calculate cost-sensitive metric.
        
        In security context:
        - False Positives: Waste analyst time investigating non-exploits
        - False Negatives: Miss actual exploited vulnerabilities (higher cost)
        
        Args:
            y_true: True labels
            y_pred: Predicted labels
            fp_cost: Cost of false positive
            fn_cost: Cost of false negative
            
        Returns:
            Total cost
        """
        tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
        
        total_cost = (fp * fp_cost) + (fn * fn_cost)
        avg_cost_per_sample = total_cost / len(y_true)
        
        print(f"\nCost-Sensitive Analysis:")
        print(f"  False Positives: {fp} × ${fp_cost} = ${fp * fp_cost}")
        print(f"  False Negatives: {fn} × ${fn_cost} = ${fn * fn_cost}")
        print(f"  Total Cost: ${total_cost}")
        print(f"  Average Cost per Sample: ${avg_cost_per_sample:.2f}")
        
        return total_cost
    
    def print_evaluation_report(self, y_true: np.ndarray, y_pred: np.ndarray,
                               y_pred_proba: np.ndarray = None):
        """
        Print comprehensive evaluation report.
        
        Args:
            y_true: True labels
            y_pred: Predicted labels
            y_pred_proba: Predicted probabilities
        """
        metrics = self.calculate_metrics(y_true, y_pred, y_pred_proba)
        
        print(f"\n{'='*60}")
        print(f"{self.model_name} - Evaluation Report")
        print(f"{'='*60}")
        
        print(f"\nClassification Metrics:")
        print(f"  Accuracy:    {metrics['accuracy']:.4f}")
        print(f"  Precision:   {metrics['precision']:.4f}")
        print(f"  Recall:      {metrics['recall']:.4f}")
        print(f"  F1-Score:    {metrics['f1']:.4f}")
        print(f"  MCC:         {metrics['mcc']:.4f}")
        
        if y_pred_proba is not None:
            print(f"\nProbability-Based Metrics:")
            print(f"  ROC-AUC:     {metrics['roc_auc']:.4f}")
            print(f"  PR-AUC:      {metrics['pr_auc']:.4f}")
        
        print(f"\nConfusion Matrix Components:")
        print(f"  True Positives:   {metrics['true_positives']}")
        print(f"  False Positives:  {metrics['false_positives']}")
        print(f"  True Negatives:   {metrics['true_negatives']}")
        print(f"  False Negatives:  {metrics['false_negatives']}")
        
        print(f"\nDerived Metrics:")
        print(f"  Specificity:  {metrics['specificity']:.4f}")
        print(f"  FPR:          {metrics['fpr']:.4f}")
        
        # Calculate cost
        self.calculate_cost_sensitive_metric(y_true, y_pred)
        
        print(f"\n{'='*60}")
        
        # Detailed classification report
        print(f"\nDetailed Classification Report:")
        print(classification_report(y_true, y_pred, 
                                   target_names=['Not Exploited', 'Exploited']))
    
    def plot_confusion_matrix(self, y_true: np.ndarray, y_pred: np.ndarray,
                             normalize: bool = False, figsize: tuple = (8, 6)):
        """
        Plot confusion matrix.
        
        Args:
            y_true: True labels
            y_pred: Predicted labels
            normalize: Whether to normalize the confusion matrix
            figsize: Figure size
        """
        cm = confusion_matrix(y_true, y_pred)
        
        if normalize:
            cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
            fmt = '.2%'
            title = f'{self.model_name} - Normalized Confusion Matrix'
        else:
            fmt = 'd'
            title = f'{self.model_name} - Confusion Matrix'
        
        plt.figure(figsize=figsize)
        sns.heatmap(cm, annot=True, fmt=fmt, cmap='Blues',
                   xticklabels=['Not Exploited', 'Exploited'],
                   yticklabels=['Not Exploited', 'Exploited'])
        plt.title(title)
        plt.ylabel('True Label')
        plt.xlabel('Predicted Label')
        plt.tight_layout()
        
        return plt.gcf()
    
    def plot_roc_curve(self, y_true: np.ndarray, y_pred_proba: np.ndarray,
                      figsize: tuple = (8, 6)):
        """
        Plot ROC curve.
        
        Args:
            y_true: True labels
            y_pred_proba: Predicted probabilities
            figsize: Figure size
        """
        fpr, tpr, thresholds = roc_curve(y_true, y_pred_proba)
        roc_auc = roc_auc_score(y_true, y_pred_proba)
        
        plt.figure(figsize=figsize)
        plt.plot(fpr, tpr, label=f'{self.model_name} (AUC = {roc_auc:.4f})', linewidth=2)
        plt.plot([0, 1], [0, 1], 'k--', label='Random Classifier')
        plt.xlim([0.0, 1.0])
        plt.ylim([0.0, 1.05])
        plt.xlabel('False Positive Rate')
        plt.ylabel('True Positive Rate')
        plt.title(f'{self.model_name} - ROC Curve')
        plt.legend(loc="lower right")
        plt.grid(alpha=0.3)
        plt.tight_layout()
        
        return plt.gcf()
    
    def plot_precision_recall_curve(self, y_true: np.ndarray, y_pred_proba: np.ndarray,
                                    figsize: tuple = (8, 6)):
        """
        Plot Precision-Recall curve.
        
        Args:
            y_true: True labels
            y_pred_proba: Predicted probabilities
            figsize: Figure size
        """
        precision, recall, thresholds = precision_recall_curve(y_true, y_pred_proba)
        pr_auc = average_precision_score(y_true, y_pred_proba)
        
        plt.figure(figsize=figsize)
        plt.plot(recall, precision, label=f'{self.model_name} (AP = {pr_auc:.4f})', linewidth=2)
        
        # Baseline (random classifier)
        baseline = y_true.sum() / len(y_true)
        plt.plot([0, 1], [baseline, baseline], 'k--', label=f'Baseline ({baseline:.4f})')
        
        plt.xlim([0.0, 1.0])
        plt.ylim([0.0, 1.05])
        plt.xlabel('Recall')
        plt.ylabel('Precision')
        plt.title(f'{self.model_name} - Precision-Recall Curve')
        plt.legend(loc="best")
        plt.grid(alpha=0.3)
        plt.tight_layout()
        
        return plt.gcf()
    
    def find_optimal_threshold(self, y_true: np.ndarray, y_pred_proba: np.ndarray,
                              metric: str = 'f1') -> tuple:
        """
        Find optimal classification threshold.
        
        Args:
            y_true: True labels
            y_pred_proba: Predicted probabilities
            metric: Metric to optimize ('f1', 'precision', 'recall')
            
        Returns:
            Tuple of (optimal_threshold, optimal_score)
        """
        thresholds = np.arange(0.1, 0.9, 0.05)
        scores = []
        
        for threshold in thresholds:
            y_pred = (y_pred_proba >= threshold).astype(int)
            
            if metric == 'f1':
                score = f1_score(y_true, y_pred, zero_division=0)
            elif metric == 'precision':
                score = precision_score(y_true, y_pred, zero_division=0)
            elif metric == 'recall':
                score = recall_score(y_true, y_pred, zero_division=0)
            else:
                raise ValueError(f"Unknown metric: {metric}")
            
            scores.append(score)
        
        optimal_idx = np.argmax(scores)
        optimal_threshold = thresholds[optimal_idx]
        optimal_score = scores[optimal_idx]
        
        print(f"\nOptimal Threshold Analysis (optimizing {metric}):")
        print(f"  Optimal Threshold: {optimal_threshold:.2f}")
        print(f"  {metric.upper()} Score: {optimal_score:.4f}")
        
        return optimal_threshold, optimal_score
    
    def plot_feature_importance(self, importance_df: pd.DataFrame, 
                               top_n: int = 20, figsize: tuple = (10, 8)):
        """
        Plot feature importance.
        
        Args:
            importance_df: DataFrame with 'feature' and 'importance' columns
            top_n: Number of top features to plot
            figsize: Figure size
        """
        top_features = importance_df.head(top_n)
        
        plt.figure(figsize=figsize)
        sns.barplot(data=top_features, x='importance', y='feature', palette='viridis')
        plt.title(f'{self.model_name} - Top {top_n} Feature Importances')
        plt.xlabel('Importance')
        plt.ylabel('Feature')
        plt.tight_layout()
        
        return plt.gcf()


def compare_models(models_results: dict, figsize: tuple = (12, 6)):
    """
    Compare multiple models.
    
    Args:
        models_results: Dictionary mapping model names to their metrics
        figsize: Figure size
    """
    metrics_to_compare = ['accuracy', 'precision', 'recall', 'f1', 'roc_auc', 'pr_auc']
    
    comparison_data = []
    for model_name, metrics in models_results.items():
        row = {'model': model_name}
        for metric in metrics_to_compare:
            if metric in metrics:
                row[metric] = metrics[metric]
        comparison_data.append(row)
    
    df = pd.DataFrame(comparison_data)
    
    # Print comparison table
    print("\n" + "="*80)
    print("Model Comparison")
    print("="*80)
    print(df.to_string(index=False))
    print("="*80)
    
    # Plot comparison
    fig, axes = plt.subplots(2, 3, figsize=figsize)
    axes = axes.ravel()
    
    for idx, metric in enumerate(metrics_to_compare):
        if metric in df.columns:
            ax = axes[idx]
            df_sorted = df.sort_values(metric, ascending=False)
            sns.barplot(data=df_sorted, x='model', y=metric, ax=ax, palette='Set2')
            ax.set_title(f'{metric.upper()}')
            ax.set_xlabel('')
            ax.set_ylabel(metric)
            ax.tick_params(axis='x', rotation=45)
    
    plt.tight_layout()
    return fig


if __name__ == "__main__":
    # Example usage
    print("Evaluation module loaded successfully!")
    print("Use ModelEvaluator class to evaluate model performance.")
