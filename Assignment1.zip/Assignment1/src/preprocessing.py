"""
Data Preprocessing Module for CVE Exploitation Prediction

Handles:
- Missing value imputation
- Feature scaling and normalization
- Train-test splitting with temporal awareness
- Data validation
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, RobustScaler
from sklearn.impute import SimpleImputer
from datetime import datetime

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent.parent))

from config import (
    TEST_SIZE, VALIDATION_SIZE, RANDOM_STATE, TEMPORAL_SPLIT_DATE
)
from src.utils import print_class_distribution, reduce_memory_usage


class DataPreprocessor:
    """Preprocess CVE feature data for modeling."""
    
    def __init__(self, temporal_split: bool = True):
        """
        Initialize preprocessor.
        
        Args:
            temporal_split: Whether to use temporal splitting (recommended)
        """
        self.temporal_split = temporal_split
        self.scaler = None
        self.imputer = None
        self.feature_columns = None
        
    def handle_missing_values(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Handle missing values in the dataset.
        
        Args:
            df: Input DataFrame
            
        Returns:
            DataFrame with imputed values
        """
        print("\nHandling missing values...")
        
        # Separate features and target
        feature_cols = [col for col in df.columns if col not in ['cve_id', 'is_exploited']]
        
        # Count missing values
        missing_counts = df[feature_cols].isnull().sum()
        missing_pct = (missing_counts / len(df)) * 100
        
        cols_with_missing = missing_counts[missing_counts > 0]
        if len(cols_with_missing) > 0:
            print(f"\nColumns with missing values:")
            for col, count in cols_with_missing.items():
                pct = missing_pct[col]
                print(f"  {col}: {count} ({pct:.2f}%)")
        
        # Strategy: median for numerical, most frequent for categorical
        # For CVSS scores, use median
        # For binary features, use 0
        
        df_copy = df.copy()
        
        for col in feature_cols:
            if df_copy[col].isnull().sum() > 0:
                # Check if binary feature (only 0s and 1s)
                unique_vals = df_copy[col].dropna().unique()
                if set(unique_vals).issubset({0, 1, 0.0, 1.0}):
                    # Binary feature - fill with 0
                    df_copy[col].fillna(0, inplace=True)
                else:
                    # Numerical feature - fill with median
                    median_val = df_copy[col].median()
                    df_copy[col].fillna(median_val, inplace=True)
        
        print(f"Missing values handled. Remaining nulls: {df_copy[feature_cols].isnull().sum().sum()}")
        
        return df_copy
    
    def scale_features(self, X_train: pd.DataFrame, X_test: pd.DataFrame) -> tuple:
        """
        Scale features using robust scaling.
        
        Args:
            X_train: Training features
            X_test: Test features
            
        Returns:
            Tuple of (scaled X_train, scaled X_test)
        """
        print("\nScaling features...")
        
        # Use RobustScaler as it's less sensitive to outliers
        self.scaler = RobustScaler()
        
        # Fit on training data only
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_test_scaled = self.scaler.transform(X_test)
        
        # Convert back to DataFrame
        X_train_scaled = pd.DataFrame(
            X_train_scaled,
            columns=X_train.columns,
            index=X_train.index
        )
        X_test_scaled = pd.DataFrame(
            X_test_scaled,
            columns=X_test.columns,
            index=X_test.index
        )
        
        print("Feature scaling complete")
        
        return X_train_scaled, X_test_scaled
    
    def temporal_train_test_split(self, df: pd.DataFrame, 
                                   split_date: str = TEMPORAL_SPLIT_DATE) -> tuple:
        """
        Split data based on temporal cutoff to prevent data leakage.
        
        This simulates real-world deployment where we train on historical data
        and predict on future vulnerabilities.
        
        Args:
            df: Input DataFrame with 'publish_year' column
            split_date: Date to split on (YYYY-MM-DD format)
            
        Returns:
            Tuple of (train_df, test_df)
        """
        print(f"\nPerforming temporal split at {split_date}...")
        
        # Convert split date to year for comparison
        split_year = int(split_date.split('-')[0])
        
        # Split based on publication year
        train_mask = df['publish_year'] < split_year
        test_mask = df['publish_year'] >= split_year
        
        train_df = df[train_mask].copy()
        test_df = df[test_mask].copy()
        
        print(f"Training set: {len(train_df)} samples ({train_df['publish_year'].min()}-{train_df['publish_year'].max()})")
        print(f"Test set: {len(test_df)} samples ({test_df['publish_year'].min()}-{test_df['publish_year'].max()})")
        
        return train_df, test_df
    
    def random_train_test_split(self, df: pd.DataFrame, 
                                 test_size: float = TEST_SIZE) -> tuple:
        """
        Perform random stratified train-test split.
        
        Args:
            df: Input DataFrame
            test_size: Fraction of data to use for testing
            
        Returns:
            Tuple of (train_df, test_df)
        """
        print(f"\nPerforming random stratified split (test size: {test_size})...")
        
        train_df, test_df = train_test_split(
            df,
            test_size=test_size,
            random_state=RANDOM_STATE,
            stratify=df['is_exploited']
        )
        
        print(f"Training set: {len(train_df)} samples")
        print(f"Test set: {len(test_df)} samples")
        
        return train_df, test_df
    
    def prepare_data(self, df: pd.DataFrame, scale: bool = True) -> dict:
        """
        Complete data preparation pipeline.
        
        Args:
            df: Input DataFrame with features and target
            scale: Whether to scale features
            
        Returns:
            Dictionary containing train/test splits and metadata
        """
        print("\n" + "="*60)
        print("Data Preprocessing Pipeline")
        print("="*60)
        
        # Handle missing values
        df = self.handle_missing_values(df)
        
        # Remove any remaining rows with missing values
        initial_len = len(df)
        df = df.dropna()
        if len(df) < initial_len:
            print(f"Dropped {initial_len - len(df)} rows with remaining missing values")
        
        # Split into train and test
        if self.temporal_split:
            train_df, test_df = self.temporal_train_test_split(df)
        else:
            train_df, test_df = self.random_train_test_split(df)
        
        # Separate features and target
        feature_cols = [col for col in df.columns if col not in ['cve_id', 'is_exploited']]
        self.feature_columns = feature_cols
        
        X_train = train_df[feature_cols]
        y_train = train_df['is_exploited']
        X_test = test_df[feature_cols]
        y_test = test_df['is_exploited']
        
        # Store CVE IDs for reference
        train_cve_ids = train_df['cve_id']
        test_cve_ids = test_df['cve_id']
        
        # Print class distributions
        print_class_distribution(y_train, "Training Set")
        print_class_distribution(y_test, "Test Set")
        
        # Scale features if requested
        if scale:
            X_train, X_test = self.scale_features(X_train, X_test)
        
        # Reduce memory usage
        X_train = reduce_memory_usage(X_train, verbose=False)
        X_test = reduce_memory_usage(X_test, verbose=False)
        
        print("\n" + "="*60)
        print("Preprocessing complete!")
        print("="*60)
        print(f"Training samples: {len(X_train)}")
        print(f"Test samples: {len(X_test)}")
        print(f"Number of features: {len(feature_cols)}")
        
        return {
            'X_train': X_train,
            'X_test': X_test,
            'y_train': y_train,
            'y_test': y_test,
            'train_cve_ids': train_cve_ids,
            'test_cve_ids': test_cve_ids,
            'feature_columns': feature_cols,
            'scaler': self.scaler
        }


def validate_data_quality(df: pd.DataFrame) -> dict:
    """
    Perform data quality checks.
    
    Args:
        df: Input DataFrame
        
    Returns:
        Dictionary of data quality metrics
    """
    print("\n" + "="*60)
    print("Data Quality Validation")
    print("="*60)
    
    metrics = {}
    
    # Check for duplicates
    duplicates = df.duplicated(subset=['cve_id']).sum()
    metrics['duplicate_cves'] = duplicates
    print(f"Duplicate CVEs: {duplicates}")
    
    # Check target distribution
    exploit_rate = df['is_exploited'].mean()
    metrics['exploitation_rate'] = exploit_rate
    print(f"Exploitation rate: {exploit_rate*100:.2f}%")
    
    # Check feature completeness
    feature_cols = [col for col in df.columns if col not in ['cve_id', 'is_exploited']]
    missing_pct = (df[feature_cols].isnull().sum() / len(df) * 100).mean()
    metrics['avg_missing_pct'] = missing_pct
    print(f"Average missing data: {missing_pct:.2f}%")
    
    # Check date range
    if 'publish_year' in df.columns:
        year_range = f"{df['publish_year'].min()}-{df['publish_year'].max()}"
        metrics['year_range'] = year_range
        print(f"Year range: {year_range}")
    
    # Check number of features
    metrics['num_features'] = len(feature_cols)
    print(f"Number of features: {len(feature_cols)}")
    
    print("="*60)
    
    return metrics


if __name__ == "__main__":
    from src.utils import load_pickle
    from config import PROCESSED_DATA_DIR
    
    # Load feature data
    feature_path = PROCESSED_DATA_DIR / 'features.pkl'
    df = load_pickle(feature_path)
    
    # Validate data quality
    quality_metrics = validate_data_quality(df)
    
    # Prepare data with temporal split
    preprocessor = DataPreprocessor(temporal_split=True)
    data = preprocessor.prepare_data(df, scale=True)
    
    print("\nData preparation successful!")
    print(f"Ready for model training with {data['X_train'].shape[1]} features")
