"""
Utility functions for the CVE Exploitation Prediction System
"""

import json
import pickle
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

import pandas as pd
import numpy as np
from tqdm import tqdm


def save_json(data: Any, filepath: Path) -> None:
    """Save data to JSON file."""
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def load_json(filepath: Path) -> Any:
    """Load data from JSON file."""
    with open(filepath, 'r', encoding='utf-8') as f:
        return json.load(f)


def save_pickle(data: Any, filepath: Path) -> None:
    """Save data to pickle file."""
    with open(filepath, 'wb') as f:
        pickle.dump(data, f)


def load_pickle(filepath: Path) -> Any:
    """Load data from pickle file."""
    with open(filepath, 'rb') as f:
        return pickle.load(f)


def parse_cve_date(date_str: str) -> Optional[datetime]:
    """
    Parse CVE date string to datetime object.
    
    Args:
        date_str: Date string in various formats
        
    Returns:
        datetime object or None if parsing fails
    """
    if not date_str:
        return None
    
    # Try different date formats
    formats = [
        '%Y-%m-%dT%H:%M:%S.%f',
        '%Y-%m-%dT%H:%M:%S',
        '%Y-%m-%d',
    ]
    
    for fmt in formats:
        try:
            return datetime.strptime(date_str.split('Z')[0], fmt)
        except (ValueError, AttributeError):
            continue
    
    return None


def calculate_age_days(published_date: str, reference_date: Optional[str] = None) -> Optional[float]:
    """
    Calculate the age of a CVE in days.
    
    Args:
        published_date: Publication date string
        reference_date: Reference date (defaults to today)
        
    Returns:
        Age in days or None if calculation fails
    """
    pub_dt = parse_cve_date(published_date)
    if pub_dt is None:
        return None
    
    if reference_date:
        ref_dt = parse_cve_date(reference_date)
    else:
        ref_dt = datetime.now()
    
    if ref_dt is None:
        return None
    
    return (ref_dt - pub_dt).days


def extract_year(date_str: str) -> Optional[int]:
    """Extract year from date string."""
    dt = parse_cve_date(date_str)
    return dt.year if dt else None


def extract_month(date_str: str) -> Optional[int]:
    """Extract month from date string."""
    dt = parse_cve_date(date_str)
    return dt.month if dt else None


def extract_quarter(date_str: str) -> Optional[int]:
    """Extract quarter (1-4) from date string."""
    dt = parse_cve_date(date_str)
    if dt:
        return (dt.month - 1) // 3 + 1
    return None


def safe_get(dictionary: Dict, *keys, default=None) -> Any:
    """
    Safely get nested dictionary values.
    
    Args:
        dictionary: Dictionary to query
        *keys: Sequence of keys to traverse
        default: Default value if key path doesn't exist
        
    Returns:
        Value at key path or default
    """
    current = dictionary
    for key in keys:
        if isinstance(current, dict):
            current = current.get(key, default)
        elif isinstance(current, list) and len(current) > 0:
            current = current[0] if isinstance(key, int) else current
        else:
            return default
    return current if current is not None else default


def rate_limit_sleep(seconds: float, message: str = "Rate limiting...") -> None:
    """
    Sleep for rate limiting with progress bar.
    
    Args:
        seconds: Number of seconds to sleep
        message: Message to display
    """
    for _ in tqdm(range(int(seconds)), desc=message, leave=False):
        time.sleep(1)


def print_class_distribution(y: pd.Series, label: str = "Dataset") -> None:
    """
    Print class distribution statistics.
    
    Args:
        y: Target variable series
        label: Label for the dataset
    """
    counts = y.value_counts()
    total = len(y)
    
    print(f"\n{label} Class Distribution:")
    print(f"{'Class':<20} {'Count':<10} {'Percentage':<10}")
    print("-" * 40)
    for cls, count in counts.items():
        pct = (count / total) * 100
        print(f"{str(cls):<20} {count:<10} {pct:.2f}%")
    print(f"{'Total':<20} {total:<10}")
    
    if len(counts) == 2:
        imbalance_ratio = counts.max() / counts.min()
        print(f"\nImbalance Ratio: {imbalance_ratio:.2f}:1")


def create_feature_importance_df(feature_names: List[str], 
                                 importances: np.ndarray) -> pd.DataFrame:
    """
    Create a sorted DataFrame of feature importances.
    
    Args:
        feature_names: List of feature names
        importances: Array of feature importance scores
        
    Returns:
        DataFrame sorted by importance
    """
    importance_df = pd.DataFrame({
        'feature': feature_names,
        'importance': importances
    })
    return importance_df.sort_values('importance', ascending=False)


def print_evaluation_metrics(metrics: Dict[str, float], title: str = "Evaluation Metrics") -> None:
    """
    Pretty print evaluation metrics.
    
    Args:
        metrics: Dictionary of metric names and values
        title: Title for the metrics display
    """
    print(f"\n{'=' * 60}")
    print(f"{title:^60}")
    print(f"{'=' * 60}")
    
    for metric, value in metrics.items():
        if isinstance(value, float):
            print(f"{metric:<30} {value:.4f}")
        else:
            print(f"{metric:<30} {value}")
    print(f"{'=' * 60}\n")


def memory_usage_mb(df: pd.DataFrame) -> float:
    """Calculate memory usage of DataFrame in MB."""
    return df.memory_usage(deep=True).sum() / 1024 / 1024


def reduce_memory_usage(df: pd.DataFrame, verbose: bool = True) -> pd.DataFrame:
    """
    Reduce memory usage of DataFrame by optimizing dtypes.
    
    Args:
        df: Input DataFrame
        verbose: Whether to print memory reduction stats
        
    Returns:
        DataFrame with optimized dtypes
    """
    start_mem = memory_usage_mb(df)
    
    for col in df.columns:
        col_type = df[col].dtype
        
        if col_type != object:
            c_min = df[col].min()
            c_max = df[col].max()
            
            if str(col_type)[:3] == 'int':
                if c_min > np.iinfo(np.int8).min and c_max < np.iinfo(np.int8).max:
                    df[col] = df[col].astype(np.int8)
                elif c_min > np.iinfo(np.int16).min and c_max < np.iinfo(np.int16).max:
                    df[col] = df[col].astype(np.int16)
                elif c_min > np.iinfo(np.int32).min and c_max < np.iinfo(np.int32).max:
                    df[col] = df[col].astype(np.int32)
            else:
                if c_min > np.finfo(np.float32).min and c_max < np.finfo(np.float32).max:
                    df[col] = df[col].astype(np.float32)
    
    end_mem = memory_usage_mb(df)
    reduction = 100 * (start_mem - end_mem) / start_mem
    
    if verbose:
        print(f'Memory usage decreased from {start_mem:.2f} MB to {end_mem:.2f} MB '
              f'({reduction:.1f}% reduction)')
    
    return df
