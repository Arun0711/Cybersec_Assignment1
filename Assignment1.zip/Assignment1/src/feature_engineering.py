"""
Feature Engineering Module for CVE Exploitation Prediction

This module extracts and engineers features from CVE data including:
- CVSS metrics (base score, exploitability, impact)
- Vulnerability types and CWE categories
- Affected software categories
- Temporal features
- NLP features from descriptions
"""

import re
from typing import Dict, List, Optional, Tuple
from collections import Counter

import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from tqdm import tqdm

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent.parent))

from config import (
    EXPLOIT_KEYWORDS, VULN_TYPE_PATTERNS, SOFTWARE_CATEGORIES,
    MAX_DESCRIPTION_LENGTH, TFIDF_MAX_FEATURES
)
from src.utils import safe_get, extract_year, extract_month, extract_quarter, calculate_age_days


class CVEFeatureExtractor:
    """Extract features from CVE data."""
    
    def __init__(self):
        """Initialize feature extractor."""
        self.tfidf_vectorizer = None
        self.feature_names = []
    
    def extract_cvss_features(self, cve_data: Dict) -> Dict[str, Optional[float]]:
        """
        Extract CVSS-based features.
        
        Args:
            cve_data: CVE data dictionary
            
        Returns:
            Dictionary of CVSS features
        """
        features = {}
        
        # Try to get CVSS v3 metrics (preferred), fall back to v2
        metrics = safe_get(cve_data, 'metrics', 'cvssMetricV31', 0, 'cvssData')
        if not metrics:
            metrics = safe_get(cve_data, 'metrics', 'cvssMetricV30', 0, 'cvssData')
        if not metrics:
            metrics = safe_get(cve_data, 'metrics', 'cvssMetricV2', 0, 'cvssData')
        
        # Base metrics
        features['cvss_base_score'] = safe_get(metrics, 'baseScore')
        features['cvss_exploitability_score'] = safe_get(
            cve_data, 'metrics', 'cvssMetricV31', 0, 'exploitabilityScore'
        ) or safe_get(cve_data, 'metrics', 'cvssMetricV30', 0, 'exploitabilityScore')
        
        features['cvss_impact_score'] = safe_get(
            cve_data, 'metrics', 'cvssMetricV31', 0, 'impactScore'
        ) or safe_get(cve_data, 'metrics', 'cvssMetricV30', 0, 'impactScore')
        
        # Attack vector
        attack_vector = safe_get(metrics, 'attackVector', default='').upper()
        features['attack_vector_network'] = 1 if attack_vector == 'NETWORK' else 0
        features['attack_vector_adjacent'] = 1 if attack_vector == 'ADJACENT_NETWORK' else 0
        features['attack_vector_local'] = 1 if attack_vector == 'LOCAL' else 0
        features['attack_vector_physical'] = 1 if attack_vector == 'PHYSICAL' else 0
        
        # Attack complexity
        attack_complexity = safe_get(metrics, 'attackComplexity', default='').upper()
        features['attack_complexity_low'] = 1 if attack_complexity == 'LOW' else 0
        features['attack_complexity_high'] = 1 if attack_complexity == 'HIGH' else 0
        
        # Privileges required
        privileges = safe_get(metrics, 'privilegesRequired', default='').upper()
        features['privileges_none'] = 1 if privileges == 'NONE' else 0
        features['privileges_low'] = 1 if privileges == 'LOW' else 0
        features['privileges_high'] = 1 if privileges == 'HIGH' else 0
        
        # User interaction
        user_interaction = safe_get(metrics, 'userInteraction', default='').upper()
        features['user_interaction_none'] = 1 if user_interaction == 'NONE' else 0
        features['user_interaction_required'] = 1 if user_interaction == 'REQUIRED' else 0
        
        # Impact metrics
        conf_impact = safe_get(metrics, 'confidentialityImpact', default='').upper()
        features['confidentiality_impact_high'] = 1 if conf_impact == 'HIGH' else 0
        features['confidentiality_impact_low'] = 1 if conf_impact in ['LOW', 'PARTIAL'] else 0
        features['confidentiality_impact_none'] = 1 if conf_impact == 'NONE' else 0
        
        integ_impact = safe_get(metrics, 'integrityImpact', default='').upper()
        features['integrity_impact_high'] = 1 if integ_impact == 'HIGH' else 0
        features['integrity_impact_low'] = 1 if integ_impact in ['LOW', 'PARTIAL'] else 0
        features['integrity_impact_none'] = 1 if integ_impact == 'NONE' else 0
        
        avail_impact = safe_get(metrics, 'availabilityImpact', default='').upper()
        features['availability_impact_high'] = 1 if avail_impact == 'HIGH' else 0
        features['availability_impact_low'] = 1 if avail_impact in ['LOW', 'PARTIAL'] else 0
        features['availability_impact_none'] = 1 if avail_impact == 'NONE' else 0
        
        # Severity rating
        severity = safe_get(cve_data, 'metrics', 'cvssMetricV31', 0, 'cvssData', 'baseSeverity', default='').upper()
        if not severity:
            severity = safe_get(cve_data, 'metrics', 'cvssMetricV30', 0, 'cvssData', 'baseSeverity', default='').upper()
        
        features['severity_critical'] = 1 if severity == 'CRITICAL' else 0
        features['severity_high'] = 1 if severity == 'HIGH' else 0
        features['severity_medium'] = 1 if severity == 'MEDIUM' else 0
        features['severity_low'] = 1 if severity == 'LOW' else 0
        
        return features
    
    def extract_cwe_features(self, cve_data: Dict) -> Dict[str, int]:
        """
        Extract CWE (Common Weakness Enumeration) features.
        
        Args:
            cve_data: CVE data dictionary
            
        Returns:
            Dictionary of CWE features
        """
        features = {}
        
        # Get CWE IDs
        weaknesses = safe_get(cve_data, 'weaknesses', default=[])
        cwe_ids = []
        
        for weakness in weaknesses:
            descriptions = weakness.get('description', [])
            for desc in descriptions:
                cwe_value = desc.get('value', '')
                if cwe_value.startswith('CWE-'):
                    cwe_ids.append(cwe_value)
        
        # Common critical CWEs
        critical_cwes = {
            'CWE-79': 'xss',  # Cross-site Scripting
            'CWE-89': 'sqli',  # SQL Injection
            'CWE-78': 'os_command_injection',
            'CWE-94': 'code_injection',
            'CWE-77': 'command_injection',
            'CWE-119': 'buffer_overflow',
            'CWE-120': 'buffer_copy',
            'CWE-20': 'input_validation',
            'CWE-22': 'path_traversal',
            'CWE-352': 'csrf',
            'CWE-434': 'file_upload',
            'CWE-502': 'deserialization',
            'CWE-287': 'auth_bypass',
            'CWE-798': 'hardcoded_credentials',
        }
        
        for cwe, name in critical_cwes.items():
            features[f'cwe_{name}'] = 1 if cwe in cwe_ids else 0
        
        features['cwe_count'] = len(cwe_ids)
        features['has_cwe'] = 1 if cwe_ids else 0
        
        return features
    
    def extract_vulnerability_type_features(self, description: str) -> Dict[str, int]:
        """
        Extract vulnerability type features from description text.
        
        Args:
            description: CVE description text
            
        Returns:
            Dictionary of vulnerability type features
        """
        features = {}
        desc_lower = description.lower()
        
        for vuln_type, patterns in VULN_TYPE_PATTERNS.items():
            features[f'vuln_type_{vuln_type}'] = int(
                any(pattern in desc_lower for pattern in patterns)
            )
        
        return features
    
    def extract_software_category_features(self, cve_data: Dict) -> Dict[str, int]:
        """
        Extract affected software category features.
        
        Args:
            cve_data: CVE data dictionary
            
        Returns:
            Dictionary of software category features
        """
        features = {}
        
        # Get CPE (Common Platform Enumeration) data
        configurations = safe_get(cve_data, 'configurations', default=[])
        cpe_strings = []
        
        for config in configurations:
            nodes = config.get('nodes', [])
            for node in nodes:
                cpe_matches = node.get('cpeMatch', [])
                for match in cpe_matches:
                    cpe_string = match.get('criteria', '').lower()
                    cpe_strings.append(cpe_string)
        
        combined_cpe = ' '.join(cpe_strings)
        
        for category, keywords in SOFTWARE_CATEGORIES.items():
            features[f'software_{category}'] = int(
                any(keyword in combined_cpe for keyword in keywords)
            )
        
        features['num_affected_products'] = len(cpe_strings)
        
        return features
    
    def extract_temporal_features(self, cve_data: Dict) -> Dict[str, Optional[float]]:
        """
        Extract temporal features.
        
        Args:
            cve_data: CVE data dictionary
            
        Returns:
            Dictionary of temporal features
        """
        features = {}
        
        published_date = safe_get(cve_data, 'published')
        
        if published_date:
            features['publish_year'] = extract_year(published_date)
            features['publish_month'] = extract_month(published_date)
            features['publish_quarter'] = extract_quarter(published_date)
            features['age_days'] = calculate_age_days(published_date)
        else:
            features['publish_year'] = None
            features['publish_month'] = None
            features['publish_quarter'] = None
            features['age_days'] = None
        
        return features
    
    def extract_description_features(self, cve_data: Dict) -> Dict:
        """
        Extract features from CVE description text.
        
        Args:
            cve_data: CVE data dictionary
            
        Returns:
            Dictionary of description-based features
        """
        features = {}
        
        # Get description
        descriptions = safe_get(cve_data, 'descriptions', default=[])
        description = ''
        for desc in descriptions:
            if desc.get('lang') == 'en':
                description = desc.get('value', '')
                break
        
        if not description and descriptions:
            description = descriptions[0].get('value', '')
        
        desc_lower = description.lower()
        
        # Keyword presence
        for keyword in EXPLOIT_KEYWORDS:
            safe_keyword = keyword.replace(' ', '_').replace('-', '_')
            features[f'keyword_{safe_keyword}'] = int(keyword in desc_lower)
        
        # Description statistics
        features['description_length'] = len(description)
        features['description_word_count'] = len(description.split())
        
        # Store full description for TF-IDF later
        features['description_text'] = description[:MAX_DESCRIPTION_LENGTH]
        
        return features
    
    def extract_reference_features(self, cve_data: Dict) -> Dict[str, int]:
        """
        Extract features from CVE references.
        
        Args:
            cve_data: CVE data dictionary
            
        Returns:
            Dictionary of reference-based features
        """
        features = {}
        
        references = safe_get(cve_data, 'references', default=[])
        
        features['num_references'] = len(references)
        
        # Check for specific reference types
        ref_tags = []
        for ref in references:
            tags = ref.get('tags', [])
            ref_tags.extend(tags)
        
        tag_counter = Counter(ref_tags)
        features['has_exploit_ref'] = 1 if 'Exploit' in tag_counter else 0
        features['has_patch_ref'] = 1 if 'Patch' in tag_counter else 0
        features['has_vendor_advisory_ref'] = 1 if 'Vendor Advisory' in tag_counter else 0
        features['has_third_party_advisory_ref'] = 1 if 'Third Party Advisory' in tag_counter else 0
        
        return features
    
    def extract_all_features(self, cve_data: Dict, cve_id: str) -> Dict:
        """
        Extract all features for a CVE.
        
        Args:
            cve_data: CVE data dictionary
            cve_id: CVE identifier
            
        Returns:
            Dictionary of all features
        """
        features = {'cve_id': cve_id}
        
        # Get description for text-based features
        descriptions = safe_get(cve_data, 'descriptions', default=[])
        description = ''
        for desc in descriptions:
            if desc.get('lang') == 'en':
                description = desc.get('value', '')
                break
        
        # Extract all feature types
        features.update(self.extract_cvss_features(cve_data))
        features.update(self.extract_cwe_features(cve_data))
        features.update(self.extract_vulnerability_type_features(description))
        features.update(self.extract_software_category_features(cve_data))
        features.update(self.extract_temporal_features(cve_data))
        features.update(self.extract_description_features(cve_data))
        features.update(self.extract_reference_features(cve_data))
        
        return features
    
    def add_tfidf_features(self, df: pd.DataFrame, max_features: int = TFIDF_MAX_FEATURES) -> pd.DataFrame:
        """
        Add TF-IDF features from description text.
        
        Args:
            df: DataFrame with 'description_text' column
            max_features: Maximum number of TF-IDF features
            
        Returns:
            DataFrame with TF-IDF features added
        """
        print("\nExtracting TF-IDF features from descriptions...")
        
        # Fill missing descriptions
        df['description_text'] = df['description_text'].fillna('')
        
        # Create TF-IDF vectorizer
        self.tfidf_vectorizer = TfidfVectorizer(
            max_features=max_features,
            stop_words='english',
            ngram_range=(1, 2),
            min_df=2,
            max_df=0.8
        )
        
        # Fit and transform
        tfidf_matrix = self.tfidf_vectorizer.fit_transform(df['description_text'])
        
        # Create DataFrame with TF-IDF features
        tfidf_feature_names = [f'tfidf_{i}' for i in range(tfidf_matrix.shape[1])]
        tfidf_df = pd.DataFrame(
            tfidf_matrix.toarray(),
            columns=tfidf_feature_names,
            index=df.index
        )
        
        # Concatenate with original DataFrame
        df = pd.concat([df, tfidf_df], axis=1)
        
        # Drop the text column as we don't need it anymore
        df = df.drop('description_text', axis=1)
        
        print(f"Added {tfidf_matrix.shape[1]} TF-IDF features")
        
        return df


def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Engineer features for all CVEs in the dataset.
    
    Args:
        df: DataFrame with 'cve_id', 'cve_data', and 'is_exploited' columns
        
    Returns:
        DataFrame with engineered features
    """
    print("\n" + "="*60)
    print("Engineering features from CVE data...")
    print("="*60)
    
    extractor = CVEFeatureExtractor()
    
    # Extract features for each CVE
    feature_list = []
    for _, row in tqdm(df.iterrows(), total=len(df), desc="Extracting features"):
        features = extractor.extract_all_features(row['cve_data'], row['cve_id'])
        features['is_exploited'] = row['is_exploited']
        feature_list.append(features)
    
    # Create DataFrame
    feature_df = pd.DataFrame(feature_list)
    
    # Add TF-IDF features
    feature_df = extractor.add_tfidf_features(feature_df)
    
    print(f"\nFeature engineering complete!")
    print(f"Total features: {len(feature_df.columns) - 2}")  # Exclude cve_id and is_exploited
    print(f"Total samples: {len(feature_df)}")
    
    return feature_df


if __name__ == "__main__":
    # Example usage
    from src.data_collection import collect_all_data
    from config import PROCESSED_DATA_DIR
    from src.utils import save_pickle
    
    # Collect data
    df = collect_all_data(use_cached=True)
    
    # Engineer features
    feature_df = engineer_features(df)
    
    # Save processed data
    output_path = PROCESSED_DATA_DIR / 'features.pkl'
    save_pickle(feature_df, output_path)
    print(f"\nSaved feature data to {output_path}")
