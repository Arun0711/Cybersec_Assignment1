"""
Configuration settings for CVE Exploitation Prediction System
"""

import os
from pathlib import Path

# Project Paths
BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / 'data'
RAW_DATA_DIR = DATA_DIR / 'raw'
PROCESSED_DATA_DIR = DATA_DIR / 'processed'
MODELS_DIR = DATA_DIR / 'models'

# Create directories if they don't exist
for dir_path in [RAW_DATA_DIR, PROCESSED_DATA_DIR, MODELS_DIR]:
    dir_path.mkdir(parents=True, exist_ok=True)

# API Configuration
NVD_API_BASE_URL = "https://services.nvd.nist.gov/rest/json/cves/2.0"
CISA_KEV_URL = "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json"

# API Rate Limiting (NVD requires 6 second delay between requests without API key)
NVD_RATE_LIMIT_DELAY = 6  # seconds
NVD_API_KEY = os.getenv('NVD_API_KEY', None)  # Set environment variable for faster access

# Data Collection Parameters
START_YEAR = 2015  # Start from 2015 for manageable dataset size
END_YEAR = 2024    # Up to 2024
RESULTS_PER_PAGE = 2000

# Feature Engineering Parameters
MAX_DESCRIPTION_LENGTH = 500  # For text features
TFIDF_MAX_FEATURES = 100  # Number of TF-IDF features to extract

# Important keywords to look for in CVE descriptions
EXPLOIT_KEYWORDS = [
    'remote', 'unauthenticated', 'code execution', 'rce', 'critical',
    'exploit', 'zero-day', 'authentication bypass', 'privilege escalation',
    'buffer overflow', 'sql injection', 'command injection', 'deserialization',
    'memory corruption', 'use after free', 'arbitrary code'
]

# Vulnerability type patterns
VULN_TYPE_PATTERNS = {
    'rce': ['remote code execution', 'rce', 'arbitrary code execution'],
    'sqli': ['sql injection', 'sqli'],
    'xss': ['cross-site scripting', 'xss'],
    'buffer_overflow': ['buffer overflow', 'heap overflow', 'stack overflow'],
    'path_traversal': ['path traversal', 'directory traversal'],
    'csrf': ['cross-site request forgery', 'csrf'],
    'xxe': ['xml external entity', 'xxe'],
    'ssrf': ['server-side request forgery', 'ssrf'],
    'deserialization': ['deserialization', 'insecure deserialization'],
    'auth_bypass': ['authentication bypass', 'authorization bypass'],
    'priv_esc': ['privilege escalation', 'elevation of privilege'],
    'dos': ['denial of service', 'dos']
}

# Software category patterns
SOFTWARE_CATEGORIES = {
    'os': ['windows', 'linux', 'unix', 'macos', 'android', 'ios'],
    'browser': ['chrome', 'firefox', 'safari', 'edge', 'internet explorer'],
    'server': ['apache', 'nginx', 'iis', 'tomcat'],
    'database': ['mysql', 'postgresql', 'oracle', 'mssql', 'mongodb'],
    'cms': ['wordpress', 'drupal', 'joomla'],
    'framework': ['spring', 'django', 'rails', 'laravel', 'express'],
    'office': ['microsoft office', 'excel', 'word', 'powerpoint'],
    'network': ['router', 'firewall', 'switch', 'vpn']
}

# Model Training Parameters
TEST_SIZE = 0.2
VALIDATION_SIZE = 0.2
RANDOM_STATE = 42

# Temporal validation cutoff (train on CVEs before this date, test on after)
TEMPORAL_SPLIT_DATE = "2023-01-01"

# Class Imbalance Handling
SMOTE_SAMPLING_STRATEGY = 0.3  # Resample minority class to 30% of majority
CLASS_WEIGHT = 'balanced'  # For models that support class weights

# Model Hyperparameters
RANDOM_FOREST_PARAMS = {
    'n_estimators': 200,
    'max_depth': 15,
    'min_samples_split': 10,
    'min_samples_leaf': 5,
    'class_weight': 'balanced',
    'random_state': RANDOM_STATE,
    'n_jobs': -1
}

XGBOOST_PARAMS = {
    'n_estimators': 200,
    'max_depth': 6,
    'learning_rate': 0.1,
    'subsample': 0.8,
    'colsample_bytree': 0.8,
    'scale_pos_weight': 10,  # Adjust based on class imbalance
    'random_state': RANDOM_STATE,
    'n_jobs': -1
}

LIGHTGBM_PARAMS = {
    'n_estimators': 200,
    'max_depth': 6,
    'learning_rate': 0.1,
    'subsample': 0.8,
    'colsample_bytree': 0.8,
    'class_weight': 'balanced',
    'random_state': RANDOM_STATE,
    'n_jobs': -1
}

# Cost-Sensitive Evaluation
# In production, false positives waste analyst time, false negatives expose systems
FP_COST = 1.0  # Cost of false positive
FN_COST = 10.0  # Cost of false negative (missing an exploited vulnerability)

# Evaluation Metrics Thresholds
CLASSIFICATION_THRESHOLD = 0.5  # Default threshold for binary classification
HIGH_RISK_THRESHOLD = 0.7  # Threshold for high-confidence predictions
