# CVE Exploitation Prediction System

## Overview
This project builds a machine learning classifier to predict whether a given CVE (Common Vulnerabilities and Exposures) will be actively exploited in the wild. The system leverages:
- **National Vulnerability Database (NVD)** for comprehensive vulnerability information
- **CISA's Known Exploited Vulnerabilities (KEV) catalog** for ground truth labels

## Problem Statement
Security teams face thousands of new vulnerabilities each year but have limited resources to patch them. This classifier helps prioritize patching efforts by predicting which vulnerabilities are most likely to be exploited.

## Key Challenges
1. **Severe Class Imbalance**: Only a small fraction of CVEs are actively exploited
2. **Data Leakage Prevention**: Must use temporal validation to simulate real-world deployment
3. **Cost-Sensitive Classification**: False positives waste resources, false negatives expose systems
4. **Feature Engineering**: Identifying what makes vulnerabilities attractive to attackers

## Project Structure
```
Assignment1/
├── data/
│   ├── raw/                 # Raw data from NVD and CISA
│   ├── processed/           # Cleaned and feature-engineered data
│   └── models/              # Trained model artifacts
├── src/
│   ├── data_collection.py   # NVD and KEV data fetching
│   ├── feature_engineering.py  # Feature extraction and creation
│   ├── preprocessing.py     # Data cleaning and preparation
│   ├── models.py            # ML model implementations
│   ├── evaluation.py        # Evaluation metrics and analysis
│   └── utils.py             # Helper functions
├── notebooks/
│   └── main_analysis.ipynb  # Complete pipeline demonstration
├── config.py                # Configuration settings
├── requirements.txt         # Python dependencies
└── README.md               # This file
```

## Installation
```bash
pip install -r requirements.txt
python -c "import nltk; nltk.download('punkt'); nltk.download('stopwords')"
```

## Important Note About NVD API

⚠️ **The NVD API may occasionally be unavailable or change endpoints.** If you encounter API errors:

1. **For this assignment**: The Jupyter notebook includes sample data generation, so it will work even without real NVD data
2. **For real data collection**: 
   - Get a free API key: https://nvd.nist.gov/developers/request-an-api-key
   - Set environment variable: `set NVD_API_KEY=your_key_here` (Windows) or `export NVD_API_KEY=your_key_here` (Linux/Mac)
   - Check NVD API status: https://nvd.nist.gov/general/news
3. **Alternative**: Download CVE data manually from NVD and place in `data/raw/`

The project is designed to work with or without live API access!

## Usage
1. **Data Collection**: Run `python src/data_collection.py` to fetch CVE and KEV data
2. **Feature Engineering**: Features are automatically extracted during preprocessing
3. **Model Training**: Use the Jupyter notebook `notebooks/main_analysis.ipynb` for the complete pipeline

## Features Engineered
### CVSS-Based Features
- Base Score, Exploitability Score, Impact Score
- Access Vector, Access Complexity, Authentication Required
- Confidentiality, Integrity, Availability Impact

### Vulnerability Characteristics
- CWE (Common Weakness Enumeration) categories
- Vulnerability types (RCE, SQLi, XSS, Buffer Overflow, etc.)
- Affected software categories (OS, Browser, Server, etc.)

### Temporal Features
- Age of vulnerability
- Publication year, month, quarter
- Days until disclosure

### NLP Features from Descriptions
- TF-IDF vectors of vulnerability descriptions
- Presence of keywords: "remote", "unauthenticated", "critical", "exploit", etc.
- Description length and complexity

## Handling Class Imbalance
1. **SMOTE** (Synthetic Minority Over-sampling Technique)
2. **Class Weights** in model training
3. **Ensemble Methods** with balanced sampling
4. **Evaluation Metrics**: Precision-Recall AUC, F1-Score, Matthews Correlation Coefficient

## Validation Methodology
- **Temporal Split**: Train on older CVEs, test on newer ones to prevent data leakage
- **Cross-Validation**: Time-series aware cross-validation
- **Operational Metrics**: Considers the cost of false positives in production environments

## Models Implemented
1. **Logistic Regression** (baseline)
2. **Random Forest** (interpretable ensemble)
3. **XGBoost** (high-performance gradient boosting)
4. **LightGBM** (efficient gradient boosting)

## Key Insights
The notebook explores:
- What vulnerability characteristics correlate with exploitation?
- Which features are most predictive?
- How to balance recall (catching exploits) vs precision (avoiding alert fatigue)?
- Real-world deployment considerations

## Author
Assignment for Cybersecurity Course - MTech Semester 2

## License
Educational use only
