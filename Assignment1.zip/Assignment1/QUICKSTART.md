# CVE Exploitation Prediction System - Quick Start Guide

## 🎯 Project Overview

This project implements a complete machine learning pipeline to predict whether CVEs (Common Vulnerabilities and Exposures) will be actively exploited in the wild using data from the National Vulnerability Database (NVD) and CISA's Known Exploited Vulnerabilities (KEV) catalog.

## 📁 Project Structure

```
Assignment1/
├── config.py                    # Configuration settings
├── requirements.txt             # Python dependencies
├── README.md                    # Main documentation
├── QUICKSTART.md               # This file
├── data/
│   ├── raw/                    # Raw CVE and KEV data
│   ├── processed/              # Feature-engineered data
│   └── models/                 # Trained model artifacts
├── src/
│   ├── data_collection.py      # NVD and KEV data fetching
│   ├── feature_engineering.py  # Feature extraction
│   ├── preprocessing.py        # Data preprocessing
│   ├── models.py               # ML model implementations
│   ├── evaluation.py           # Evaluation metrics
│   └── utils.py                # Helper functions
└── notebooks/
    └── main_analysis.ipynb     # Complete analysis notebook
```

## 🚀 Quick Start

### Step 1: Install Dependencies

```bash
pip install -r requirements.txt
python -c "import nltk; nltk.download('punkt'); nltk.download('stopwords')"
```

### Step 2: Collect Data (Optional - can use cached data)

**Warning**: NVD API has rate limits (6 seconds between requests without API key). Initial data collection may take hours.

```bash
# Option A: Get NVD API key (recommended for faster collection)
# Visit: https://nvd.nist.gov/developers/request-an-api-key
# Set environment variable: set NVD_API_KEY=your_key_here

# Option B: Collect data (this will take time!)
python src/data_collection.py
```

### Step 3: Run the Complete Analysis

Open and run the Jupyter notebook:

```bash
jupyter notebook notebooks/main_analysis.ipynb
```

The notebook is self-contained and includes:
- ✅ Data loading (uses sample data if real data unavailable)
- ✅ Exploratory data analysis
- ✅ Feature engineering
- ✅ Model training with SMOTE
- ✅ Comprehensive evaluation
- ✅ Feature importance analysis
- ✅ Cost-sensitive metrics
- ✅ Threshold optimization

## 📊 Key Features

### 1. Comprehensive Feature Engineering (30+ features)

**CVSS Metrics**:
- Base score, exploitability score, impact score
- Attack vector (network, adjacent, local, physical)
- Attack complexity (low, high)
- Privileges required (none, low, high)
- User interaction (none, required)
- Impact scores (confidentiality, integrity, availability)

**Vulnerability Characteristics**:
- CWE categories (SQL injection, XSS, buffer overflow, etc.)
- Vulnerability types extracted from descriptions
- Software categories (OS, browser, server, database, etc.)

**Temporal Features**:
- Publication year, month, quarter
- Age of vulnerability
- Days since disclosure

**NLP Features**:
- TF-IDF vectors from descriptions
- Keyword presence (remote, unauthenticated, critical, etc.)
- Description statistics

### 2. Proper Handling of Class Imbalance

- **SMOTE**: Synthetic minority over-sampling
- **Class Weights**: Balanced training
- **Appropriate Metrics**: PR-AUC, F1-Score, MCC

### 3. Temporal Validation (Prevents Data Leakage)

- Train on 2015-2022 CVEs
- Test on 2023+ CVEs
- Simulates real-world deployment

### 4. Multiple Models

- Logistic Regression (baseline)
- Random Forest (interpretable)
- XGBoost (high performance)
- LightGBM (efficient)

### 5. Cost-Sensitive Evaluation

- False Negative Cost: $10 (security risk)
- False Positive Cost: $1 (operational overhead)
- Optimizes for operational deployment

## 🎓 Learning Objectives Demonstrated

✅ **Data Collection**: Integration of multiple security data sources

✅ **Feature Engineering**: Domain knowledge applied to create predictive features

✅ **Class Imbalance**: Proper handling with SMOTE and evaluation metrics

✅ **Data Leakage Prevention**: Temporal validation methodology

✅ **Model Selection**: Comparison of multiple algorithms

✅ **Interpretability**: Feature importance analysis

✅ **Operational Context**: Cost-sensitive metrics and threshold optimization

✅ **Critical Thinking**: Analysis of what makes vulnerabilities exploitable

## 📈 Expected Results

With real data, the models typically achieve:
- **ROC-AUC**: 0.80-0.90
- **PR-AUC**: 0.30-0.60 (significantly above baseline ~0.05)
- **F1-Score**: 0.40-0.70 (depending on threshold)
- **Recall**: 0.60-0.85 (adjustable via threshold)

## 🔧 Customization

### Modify Configuration

Edit `config.py` to change:
- Data collection years
- SMOTE sampling strategy
- Model hyperparameters
- Cost weights
- API settings

### Add New Features

Edit `src/feature_engineering.py`:
```python
def extract_custom_features(self, cve_data: Dict) -> Dict:
    # Add your custom feature extraction logic
    pass
```

### Try Different Models

Add new models in `src/models.py`:
```python
class CustomClassifier(CVEClassifier):
    def build_model(self):
        self.model = YourModel()
```

## 🐛 Troubleshooting

### Issue: NVD API Rate Limit Errors

**Solution**: 
1. Get free API key from https://nvd.nist.gov/developers/request-an-api-key
2. Set environment variable: `set NVD_API_KEY=your_key_here`
3. This increases rate limit from 5 to 50 requests per 30 seconds

### Issue: No cached data available

**Solution**: 
- The notebook includes sample data generation for demonstration
- For real analysis, run: `python src/data_collection.py`

### Issue: Out of memory during SMOTE

**Solution**: 
- Reduce `SMOTE_SAMPLING_STRATEGY` in `config.py`
- Use subset of data for initial experimentation
- Consider using class weights instead of SMOTE

### Issue: TF-IDF errors

**Solution**:
```bash
python -c "import nltk; nltk.download('punkt'); nltk.download('stopwords')"
```

## 📚 Additional Resources

### Understanding CVE Data
- NVD: https://nvd.nist.gov/
- CISA KEV: https://www.cisa.gov/known-exploited-vulnerabilities-catalog
- CVSS: https://www.first.org/cvss/

### Machine Learning for Security
- Imbalanced Learning: https://imbalanced-learn.org/
- SMOTE Paper: https://arxiv.org/abs/1106.1813
- Cost-Sensitive Learning: https://machinelearningmastery.com/cost-sensitive-learning/

### Papers and Research
- "Predicting Exploitability of Security Vulnerabilities" 
- "Machine Learning for Vulnerability Assessment"
- "Temporal Analysis of CVE Exploitation"

## 🎯 Next Steps

1. **Collect Real Data**: Run data collection script for actual CVE data
2. **Feature Engineering**: Experiment with additional features
3. **Hyperparameter Tuning**: Use GridSearchCV or RandomizedSearchCV
4. **Ensemble Methods**: Combine multiple models
5. **Time Series Analysis**: Analyze exploitation trends over time
6. **Deployment**: Integrate into security operations workflow
7. **Continuous Learning**: Set up regular model retraining

## 💡 Tips for Success

- Start with the notebook - it's self-contained and educational
- Use sample data first to understand the pipeline
- Read the markdown cells in the notebook for explanations
- Experiment with different thresholds for your use case
- Pay attention to PR-AUC more than ROC-AUC for imbalanced data
- Consider operational costs when setting thresholds
- Retrain regularly as new CVEs and exploits emerge

## 📝 Assignment Deliverables Checklist

✅ Complete data collection pipeline from NVD and CISA KEV
✅ Comprehensive feature engineering (30+ features)
✅ Proper handling of severe class imbalance
✅ Temporal validation to prevent data leakage
✅ Multiple model implementations and comparison
✅ Cost-sensitive evaluation metrics
✅ Feature importance analysis
✅ Threshold optimization for deployment
✅ Well-documented Jupyter notebook
✅ Critical thinking about vulnerability exploitation factors
✅ Operational deployment considerations

## 🤝 Support

For questions or issues:
1. Review the notebook's markdown cells for explanations
2. Check this QUICKSTART.md for common issues
3. Consult the main README.md for architecture details
4. Review code comments in src/ modules

---

**Good luck with your cybersecurity machine learning project! 🔒🤖**
